#!/bin/bash

# 检查是否以root用户运行
if [ "$EUID" -ne 0 ]; then
  echo "请以root用户运行此脚本。"
  exit 1
fi

echo "-----------------------------------------"

echo "==========数据库备份配置开始=========="
BACKUP_SCRIPT=`pwd`/mysqlBack.sh

 # 检查备份脚本是否存在
 if [ ! -f "$BACKUP_SCRIPT" ]; then
   echo "备份脚本 $BACKUP_SCRIPT 不存在。请确保脚本路径正确。"
   exit 1
 fi

 # 设置备份脚本权限
 chmod +x "$BACKUP_SCRIPT"

 # 定义crontab条目
 CRON_JOB="0 0 12 * * $BACKUP_SCRIPT"

 # 检查crontab是否已经包含该条目
 if crontab -l | grep -Fq "$BACKUP_SCRIPT"; then
   echo "定时任务已经存在。"
 else
   # 添加crontab条目
   (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
   echo "定时任务已添加。"
 fi

 # 检查crontab状态
 echo "当前crontab条目："
 crontab -l

 echo "==========数据库备份配置完成=========="
