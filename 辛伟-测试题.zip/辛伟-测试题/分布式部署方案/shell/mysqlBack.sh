#!/bin/bash

# 备份文件保存地址
backup_dir=`pwd`/mysqlBack

# 备份文件的有效期，单位为day
backup_days="30"

dd=`date +%Y-%m-%d-%H-%M-%S`


if [ ! -d $backup_dir ];
then
    mkdir -p $backup_dir;
fi

# 使用docker容器中命令
# 备份 xxk\l-job 数据库
database="xxl-job"
backup_file="$backup_dir/$database-$dd.sql"
docker exec -it mysql8-compose mysqldump -hmysql --default-character-set=utf8mb4 --hex-blob -c --add-drop-table $database > $backup_file

# 压缩sql文件
gzip -f $backup_file


# 清除过期的文件
find $backup_dir -name "*.sql.gz" -mtime +$backup_days -exec rm {} \;
