# Docker-compose 一键部署说明文档

---

### **目录**

1. **网络配置**
2. **服务配置**
   - MySQL
   - Nginx
   - MinIO
   - Redis
   - XXL-Job 管理平台
   - Prometheus
   - Redis Exporter
   - MySQL Exporter
   - Grafana
   - Alertmanager
3. **数据备份**

---

### **网络配置**

自定义的桥接网络，用于在服务之间进行通信。

```yaml
networks:
  netcoon:
    driver: bridge
```

---

### **服务配置**

#### **MySQL**

```yaml
mysql:
  restart: always
  image: mysql:8.0
  container_name: mysql8-compose
  volumes:
    # 数据目录映射到主机目录，mysql数据目录
    - ./mysql/db:/var/lib/mysql
    # 配置目录映射到主机目录，mysql相关配置文件
    - ./mysql/conf:/etc/mysql/conf.d
    # 日志目录映射到主机目录
    - ./mysql/logs:/logs
    # 初始化脚本目录映射到主机目录，主要存放初始化脚本
    - ./mysql/init/:/docker-entrypoint-initdb.d/
  command:
    --character-set-server=utf8mb4
    --collation-server=utf8mb4_general_ci
    --explicit_defaults_for_timestamp=true
  environment:
    # 设置root密码以及初始化一个普通用户
    MYSQL_ROOT_PASSWORD: ${MYSQL_ROOT_PASSWORD}
    MYSQL_USER: ${MYSQL_ORI_USER}
    MYSQL_PASSWORD: ${MYSQL_ORI_PWD}
    MYSQL_INITDB_SKIP_TZINFO: "Asia/Shanghai"
  ports:
    # 端口映射
    - "3307:3306"
  networks:
    - netcoon
```

- **image**: 使用 MySQL 8.0 版本的镜像。
- **container_name**: 容器名称为 `mysql8-compose`。
- **volumes**:
  - `./mysql/db:/var/lib/mysql`: 数据目录映射到主机目录。
  - `./mysql/conf:/etc/mysql/conf.d`: 配置目录映射到主机目录。
  - `./mysql/logs:/logs`: 日志目录映射到主机目录。
  - `./mysql/init/:/docker-entrypoint-initdb.d/`: 初始化脚本目录映射到主机目录，该目录下的 SQL 文件在创建容器时会自动执行。
- **command**: 设置 MySQL 的启动参数，包括字符集、排序规则和时间戳处理。
- **environment**:
  - `MYSQL_ROOT_PASSWORD`: 设置 MySQL 的 root 密码。
  - `MYSQL_USER`: 初始化一个普通用户。
  - `MYSQL_PASSWORD`: 设置普通用户的密码。
  - `MYSQL_INITDB_SKIP_TZINFO`: 设置时区。
- **ports**: 将 MySQL 的 3306 端口映射到主机的 3307 端口。
- **networks**: 使用 `netcoon` 网络。
- **restart**: 始终自动重启 MySQL 容器。

---

#### **Nginx**

```yaml
nginx:
  # nginx最新镜像
  image: nginx:latest
  # 定义容器名称
  container_name: nginx-compose
  # 配置nginx环境
  environment:
    - TZ=Asia/Shanghai
  # 配置端口
  ports:
    - "20006:20006"
  networks:
    - netcoon
  # 配置挂载的文件夹
  volumes:
    # 配置文件映射到主机目录，nginx server相关配置文件
    - ./nginx/conf/nginx.conf:/etc/nginx/nginx.conf
    # 项目根目录映射到主机目录
    - ./nginx/html:/etc/nginx/html
    # 日志目录映射到主机目录，nginx访问和错误日志
    - ./nginx/logs:/var/log/nginx
  # 自动重启
  restart: always
```

- **image**: 使用 Nginx 最新版本的镜像。
- **container_name**: 容器名称为 `nginx-compose`。
- **environment**:
  - `TZ=Asia/Shanghai`: 设置时区。
- **ports**:
  - `20006:20006`: 将 Nginx 的 20006 端口映射到主机的 20006 端口。
- **networks**: 使用 `netcoon` 网络。
- **volumes**:
  - `./nginx/conf/nginx.conf:/etc/nginx/nginx.conf`: 配置文件映射到主机。
  - `./nginx/html:/usr/share/nginx/html`: 项目根目录映射到主机目录。
  - `./nginx/logs:/var/log/nginx`: 日志目录映射到主机目录。
- **restart**: 始终自动重启 Nginx 容器。

---

#### **MinIO**

```yaml
minio:
  # minio最新镜像
  image: quay.io/minio/minio
  # 定义容器名称
  container_name: minio-compose
  # 配置端口
  ports:
    - "9000:9000"
    - "9001:9001"
  environment:
    - TZ=Asia/Shanghai
    - MINIO_ROOT_USER=${MINIO_USER}
    - MINIO_ROOT_PASSWORD=${MINIO_PWD}
  volumes:
    # 数据存放目录映射到主机目录
    - ./minio/data:/data
  # 启动minio指定对应的数据目录以及访问端口
  command: server /data --console-address ":9001" --address ":9000"
  networks:
    - netcoon
  # 自动重启
  restart: always
```

- **image**: 使用 MinIO 的镜像。
- **container_name**: 容器名称为 `minio-compose`。
- **ports**:
  - `9000:9000`: MinIO 服务器端口。
  - `9001:9001`: MinIO 控制台端口。
- **environment**:
  - `TZ=Asia/Shanghai`: 设置时区。
  - `MINIO_ROOT_USER`: 设置 MinIO 的 root 用户。
  - `MINIO_ROOT_PASSWORD`: 设置 MinIO 的 root 密码。
- **volumes**:
  - `./minio/data:/data`: 数据存放目录映射到主机目录。
- **command**: 启动 MinIO 指定对应的数据目录及访问端口。
- **networks**: 使用 `netcoon` 网络。
- **restart**: 始终自动重启 MinIO 容器。

---

#### **Redis**

```yaml
redis:
  # 设置容器对应的镜像
  image: redis:6.2.8
  # 设置容器名
  container_name: redis-compose
  # 配置环境
  environment:
    - TZ=Asia/Shanghai
  # 端口映射
  ports:
    - "16379:6379"
  networks:
    - netcoon
  # 挂载文件夹
  volumes:
    # 配置文件目录的挂载
    - ./redis/conf:/etc/redis
    # 数据目录的挂载
    - ./redis/data:/data
    # 日志目录的挂载
    - ./redis/logs:/var/log/redis
  # 设置命令
  command: redis-server /etc/redis/redis.conf --appendonly no
  # 自动重启
  restart: always
```

- **image**: 使用 Redis 6.2.8 版本的镜像。
- **container_name**: 容器名称为 `redis-compose`。
- **environment**:
  - `TZ=Asia/Shanghai`: 设置时区。
- **ports**: 将 Redis 的 6379 端口映射到主机的 16379 端口。
- **networks**: 使用 `netcoon` 网络。
- **volumes**:
  - `./redis/conf:/etc/redis`: 配置文件目录映射到主机目录。
  - `./redis/data:/data`: 数据目录映射到主机目录。
  - `./redis/logs:/var/log/redis`: 日志目录映射到主机目录。
- **command**: 设置 Redis 的启动参数。
- **restart**: 始终自动重启 Redis 容器。

---

#### **XXL-Job 管理平台**

```yaml
xxl-job-admin:
  restart: always
  # docker 镜像
  image: xuxueli/xxl-job-admin:2.3.1
  # 容器名称
  container_name: xxl-job-admin
  volumes:
    # 日志目录映射到主机目录
    - ./xxl-job/logs:/data/applogs
  depends_on:
    # 容器的依赖关系，该项目依赖于mysql
    - mysql
  ports:
    # 端口映射
    - "8089:8089"
  networks:
    - netcoon
  environment:
    # 设置启动参数
    PARAMS: '
      --server.port=8089
      --server.servlet.context-path=/xxl-job-admin
      --spring.datasource.url=jdbc:mysql://mysql:3306/xxl_job?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true
      --spring.datasource.username=${MYSQL_ROOT_USERNAME}
      --spring.datasource.password=${MYSQL_ROOT_PASSWORD}
      --xxl.job.accessToken=${XXL_JOB_ACCESS_TOKEN}'
```

- **image**: 使用 XXL-Job 2.3.1 版本的管理平台镜像。
- **container_name**: 容器名称为 `xxl-job-admin`。
- **volumes**:
  - `./xxl-job/logs:/data/applogs`: 日志目录映射到主机目录。
- **depends_on**: 依赖于 MySQL 服务。
- **ports**: 将 XXL-Job 的 8089 端口映射到主机的 8089 端口。
- **networks**: 使用 `netcoon` 网络。
- **environment**:
  - `PARAMS`: 设置启动参数，包括端口、上下文路径、数据源 URL、用户名、密码和访问令牌。

---

#### **Prometheus**

```yaml
prometheus:
  image: prom/prometheus:latest
  container_name: prometheus
  restart: always
  ports:
    - "9090:9090"
  volumes:
    # 配置文件映射到主机目录
    - ./prometheus/prometheus.yml:/etc/prometheus/prometheus.yml
    # 数据目录映射到主机目录
    - ./prometheus/data:/prometheus
  networks:
    - netcoon
```

- **image**: 使用 Prometheus 最新版本的镜像。
- **container_name**: 容器名称为 `prometheus`。
- **restart**: 始终自动重启 Prometheus 容器。
- **ports**: 将 Prometheus 的 9090 端口映射到主机的 9090 端口。
- **volumes**:
  - `./prometheus/prometheus.yml:/etc/prometheus/prometheus.yml`: 配置文件映射到主机目录。
  - `./prometheus/data:/prometheus`: 数据目录映射到主机目录。
- **networks**: 使用 `netcoon` 网络。

---

#### **Redis Exporter**

```yaml
redis-exporter:
  image: oliver006/redis_exporter
  container_name: redis-exporter
  ports:
    - "9121:9121"
  environment:
    # 设置redis地址
    - REDIS_ADDR=redis://redis-compose:6379
    - REDIS_PASSWORD=${REDIS_PWD}
  networks:
    - netcoon
  depends_on:
    # 容器的依赖关系，该项目依赖于redis
    - redis
```

- **image**: 使用 Redis Exporter 的镜像。
- **container_name**: 容器名称为 `redis-exporter`。
- **ports**: 将 Redis Exporter 的 9121 端口映射到主机的 9121 端口。
- **environment**:
  - `REDIS_ADDR`: 设置 Redis 地址。
  - `REDIS_PASSWORD`: 设置 Redis 密码。
- **networks**: 使用 `netcoon` 网络。
- **depends_on**: 依赖于 Redis 服务。

---

#### **MySQL Exporter**

```yaml
mysqld-exporter:
  image: prom/mysqld-exporter
  container_name: mysqld-exporter
  restart: always
  ports:
    - "9104:9104"
  environment:
    # 设置mysql地址
    - DATA_SOURCE_NAME=${MYSQL_ORI_USER}:${PROM_DB_PWD}@(mysql:3306)/
  volumes:
    # 配置文件映射到主机目录
    - ./mysqld-exporter/.my.cnf:/.my.cnf
  networks:
    - netcoon
  depends_on:
    # 容器的依赖关系，该项目依赖于mysql
    - mysql
```

- **image**: 使用 MySQL Exporter 的镜像。
- **container_name**: 容器名称为 `mysqld-exporter`。
- **restart**: 始终自动重启 MySQL Exporter 容器。
- **ports**: 将 MySQL Exporter 的 9104 端口映射到主机的 9104 端口。
- **environment**:
  - `DATA_SOURCE_NAME`: 设置 MySQL 数据源名称。
- **volumes**:
  - `./mysqld-exporter/.my.cnf:/.my.cnf`: MySQL 配置文件映射到主机目录。
- **networks**: 使用 `netcoon` 网络。
- **depends_on**: 依赖于 MySQL 服务。

---

#### **Grafana**

```yaml
grafana:
  image: grafana/grafana:10.1.2
  container_name: grafana
  restart: always
  ports:
    - "3000:3000"
  volumes:
    # 配置文件映射到主机目录
    - ./grafana/conf:/etc/grafana
    - ./grafana/data:/var/lib/grafana
  environment:
    - TZ=Asia/Shanghai
  networks:
    - netcoon
```

- **image**: 使用 Grafana 10.1.2 版本的镜像。
- **container_name**: 容器名称为 `grafana`。
- **restart**: 始终自动重启 Grafana 容器。
- **ports**: 将 Grafana 的 3000 端口映射到主机的 3000 端口。
- **volumes**:
  - `./grafana/conf:/etc/grafana`: 配置文件目录映射到主机目录。
  - `./grafana/data:/var/lib/grafana`: 数据目录映射到主机目录。
- **environment**:
  - `TZ=Asia/Shanghai`: 设置时区。
- **networks**: 使用 `netcoon` 网络。

---

#### Alertmanager

```
alertmanager:
    image: prom/alertmanager:latest
    container_name: alertmanager
    restart: always
    ports:
      - "9093:9093"
    volumes:
      - ./alertmanager:/etc/alertmanager
    networks:
      - netcoon
```

- **image**: 使用 `prom/alertmanager:latest` 镜像。
- **container_name**: 容器名称为 `alertmanager`。
- **restart**: 始终自动重启 Alertmanager 容器。
- **ports**: 将 Alertmanager 的 9093 端口映射到主机的 9093 端口。
- **volumes**:
  - `./alertmanager:/etc/alertmanager`: 配置文件目录映射到主机目录。
- **networks**: 使用 `netcoon` 网络。

---

### **配置文件示例**

#### **Prometheus 配置文件 (prometheus.yml)**

创建 `./prometheus/prometheus.yml` 文件，内容如下：

```yaml
global:
  scrape_interval: 5s  # 抓取间隔时间

scrape_configs:
  - job_name: 'redis'
    static_configs:
      - targets: ['redis-exporter:9121']
  - job_name: 'mysql'
    static_configs:
      - targets: ['mysqld-exporter:9104']
```

---

#### **MySQL Exporter 配置文件 (.my.cnf)**

创建 `./mysqld-exporter/.my.cnf` 文件，内容如下：

```ini
[client]
user=root
password=Abc123654
host=mysql
port=3306
```

确保 `.my.cnf` 文件的权限正确：

```bash
chmod 0600 ./mysqld-exporter/.my.cnf
```

---

#### **Grafana 配置文件 (grafana.ini)**

创建 `./grafana/conf/grafana.ini` 文件，内容如下：

```ini
[default]
default_language = zh

[users]
default_language = zh
```

---

### **Grafana 仪表盘模板ID**

- **MySQL 仪表盘**: 在仪表盘导入对应的模板 ID `7362`。
- **Redis 仪表盘**: 在仪表盘导入对应的模板 ID `11835`。

---

### **环境变量**

为了确保配置文件中的环境变量能够正确解析，你需要在运行 `docker-compose` 之前设置这些环境变量。你可以在 `.env` 文件中定义这些变量，或者直接在命令行中设置。

#### **.env 文件示例**

创建 `.env` 文件，内容如下：

```ini
# mysql账号密码
# mysql root密码
MYSQL_ROOT_USERNAME=root
MYSQL_ROOT_PASSWORD=Xinwei@2025

# mysql普通账号密码
MYSQL_ORI_USER=prometheus
MYSQL_ORI_PWD=Prometheus@Query@2006

# minio 账号密码
MINIO_USER=minio
MINIO_PWD=minio12345678

# xxl-job accessToken
XXL_JOB_ACCESS_TOKEN=xdsl3ewi3alloehxmo6788pqxer

# 普罗米修斯监控数据库账号密码
PROM_DB_USER=root
PROM_DB_PWD=Xinwei@2025

# redis密码
REDIS_PWD=YgvCaY6t
```

确保 `.env` 文件与 `docker-compose.yml` 文件在同一目录下。

---

### **运行 docker-compose**

在包含 `docker-compose.yml` 文件的目录中运行以下命令来启动所有服务：

```bash
docker-compose up -d
```

---

### **验证配置**

使用以下命令来验证 `docker-compose.yml` 文件的配置是否正确：

```bash
docker-compose config
```

---

### **访问服务**

- **MySQL**: 通过 `localhost:3307` 访问 MySQL。
- **Nginx**: 通过 `http://localhost:20006` 访问 Nginx。
- **MinIO**:
  - 通过 `http://localhost:9000` 访问 MinIO 服务器。
  - 通过 `http://localhost:9001` 访问 MinIO 控制台。
- **Redis**: 通过 `localhost:16379` 访问 Redis。
- **XXL-Job 管理平台**: 通过 `http://localhost:8089/xxl-job-admin` 访问 XXL-Job 管理平台。
- **Prometheus**: 通过 `http://localhost:9090` 访问 Prometheus。
- **Redis Exporter**: 通过 `http://localhost:9121/metrics` 访问 Redis Exporter 的指标。
- **MySQL Exporter**: 通过 `http://localhost:9104/metrics` 访问 MySQL Exporter 的指标。
- **Grafana**: 通过 `http://localhost:3000` 访问 Grafana。默认用户名为 `admin`，默认密码为 `admin`。
- **Alertmanager:**通过 `http://localhost:9093` 访问 Alertmanager。

---

### **数据备份**

#### **Shell 脚本说明**

进入当前目录下的 `shell` 文件夹，其中有两个 Shell 脚本：

1. **mysqlBack.sh**: 数据库备份脚本。
2. **setting.sh**: 设置定时备份数据库任务。

---

### **查看日志指令**

1. **MySQL 日志**:
   ```bash
   docker-compose logs mysql
   ```

2. **Nginx 日志**:
   ```bash
   docker-compose logs nginx
   ```

3. **MinIO 日志**:
   ```bash
   docker-compose logs minio
   ```

4. **Redis 日志**:
   ```bash
   docker-compose logs redis
   ```

5. **XXL-Job 管理平台日志**:
   ```bash
   docker-compose logs xxl-job-admin
   ```

6. **Prometheus 日志**:
   ```bash
   docker-compose logs prometheus
   ```

7. **Redis Exporter 日志**:
   ```bash
   docker-compose logs redis-exporter
   ```

8. **MySQL Exporter 日志**:
   ```bash
   docker-compose logs mysqld-exporter
   ```

9. **Grafana 日志**:
   ```bash
   docker-compose logs grafana
   ```

10. **Alertmanager**

    ```
    docker-compose logs alertmanager
    ```

    

### **总结：**

1. 访问各个服务的 Web 界面或 API。
2. 使用 `mysqlBack.sh` 脚本手动备份 MySQL 数据库。
3. 使用 `setting.sh` 脚本设置定时备份任务。
4. 使用 `docker-compose logs` 命令查看各个容器的日志，便于排查问题。
