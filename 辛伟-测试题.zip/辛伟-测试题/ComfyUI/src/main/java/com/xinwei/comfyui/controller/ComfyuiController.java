package com.xinwei.comfyui.controller;

import cn.hutool.core.text.CharSequenceUtil;
import com.xinwei.comfyui.model.QueueResultData;
import com.xinwei.comfyui.model.api.R;
import com.xinwei.comfyui.model.PomiontReq;
import com.xinwei.comfyui.service.ComfyuiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @Description: Comfyui控制器
 * @Author: xinwei
 * @Date: 2025/3/5 23:02
 * @since 1.8
 */
@RestController
@RequestMapping("/api/v1/")
public class ComfyuiController {
    @Autowired
    ComfyuiService comfyuiService;
    /**
     * 生成图片
     * @param req
     * @return
     */
    @PostMapping("generate")
    public R generate(@RequestBody PomiontReq req) {
        String result = comfyuiService.generate(req.getPositive(), req.getNegative());
        if (CharSequenceUtil.isNotBlank(result)) {
            return R.success("生成图片任务创建成功，prompt_id："+result);
        }
            return R.fail("生成失败");
    }

    /**
     * 获取当前的任务状态信息
     * @param taskId
     * @return
     */
    @GetMapping("tasks/{taskId}")
    public R tasks(@PathVariable String taskId) {
        Map<String, String> result = comfyuiService.getTask(taskId);
        return R.data(result);
    }
    /**
     * 获取运行中的任务ID，排队中的任务ID列表
     */
    @GetMapping("queue")
    public R<QueueResultData> queue() {
        QueueResultData result = comfyuiService.getQueue();
        return R.data(result);
    }
    /**
     * 取消正在排队中的任务
     * @return
     */
    @DeleteMapping("tasks")
    public R delete() {
        comfyuiService.deleteTask("");
        return R.success("取消成功");
    }

    /**
     * 取消当前执行中的任务
     * @return
     */
    @DeleteMapping("interrupt")
    public R interrupt() {
        comfyuiService.interruptTask();
        return R.success("取消成功");
    }
}
