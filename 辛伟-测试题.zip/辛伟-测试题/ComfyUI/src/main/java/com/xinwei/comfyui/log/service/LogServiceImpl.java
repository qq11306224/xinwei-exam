package com.xinwei.comfyui.log.service;

import cn.hutool.json.JSONUtil;
import com.xinwei.comfyui.log.model.LogError;
import com.xinwei.comfyui.log.model.LogUsual;
import com.xinwei.comfyui.log.strategy.LogStrategyFactory;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


/**
 * @Description: 日志服务实现类
 * @Author: xinwei
 * @Date: 2025/3/6 14:22
 * @since 1.8
 */
@Service
@AllArgsConstructor
@Slf4j
public class LogServiceImpl implements ILogService {

	private final LogStrategyFactory logStrategyFactory;
	@Override
	public void saveUsualLog(LogUsual logUsual) {
		//可在通过配置策略模式选择其中一种存储日志方式
		logStrategyFactory.getStrategy("default").saveUsualLog(logUsual);
		logStrategyFactory.getStrategy("redis").saveUsualLog(logUsual);
		logStrategyFactory.getStrategy("db").saveUsualLog(logUsual);
	}


	@Override
	public void saveErrorLog(LogError logError) {
		//可在通过配置策略模式选择其中一种存储日志方式
		logStrategyFactory.getStrategy("default").saveErrorLog(logError);
		logStrategyFactory.getStrategy("redis").saveErrorLog(logError);
		logStrategyFactory.getStrategy("db").saveErrorLog(logError);
	}

}
