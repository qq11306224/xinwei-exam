
package com.xinwei.comfyui.log.publisher;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.xinwei.comfyui.log.event.ErrorLogEvent;
import com.xinwei.comfyui.log.model.LogError;
import com.xinwei.comfyui.log.utils.LogAbstractUtil;
import com.xinwei.comfyui.log.utils.WebUtil;
import jakarta.servlet.http.HttpServletRequest;

import java.util.HashMap;
import java.util.Map;
/**
 * @Description: 异常日志发布者
 * @Author: xinwei
 * @Date: 2025/3/6 14:22
 * @since 1.8
 */
public class ErrorLogPublisher {
    public ErrorLogPublisher() {
    }

    public static void publishEvent(Throwable error,String errorMsg) {
        HttpServletRequest request = WebUtil.getRequest();
        LogError logError = new LogError();
        if (ObjectUtil.isNotEmpty(error)) {
           // logError.setStackTrace(Exceptions.getStackTraceAsString(error));
            logError.setExceptionName(error.getClass().getName());
            if (StrUtil.isNotBlank(errorMsg)) {
                logError.setMessage(errorMsg);
            }else {
                logError.setMessage(error.getMessage());
            }
            logError.setMessage(error.getMessage());
            StackTraceElement[] elements = error.getStackTrace();
            if (ObjectUtil.isNotEmpty(elements)) {
                StackTraceElement element = elements[0];
                logError.setMethodName(element.getMethodName());
                logError.setMethodClass(element.getClassName());
                logError.setFileName(element.getFileName());
                logError.setLineNumber(element.getLineNumber());
            }
        }

        LogAbstractUtil.addRequestInfoToLog(request, logError);
        Map<String, Object> event = new HashMap(16);
        event.put("log", logError);
        event.put("request", request);
        SpringUtil.publishEvent(new ErrorLogEvent(event));
    }
}
