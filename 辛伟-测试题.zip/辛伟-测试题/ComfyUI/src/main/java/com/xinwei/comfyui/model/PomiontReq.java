package com.xinwei.comfyui.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description: 生成图片请求对象
 * @Author: xinwei
 * @Date: 2025/3/6 11:01
 * @since 1.8
 */

public class PomiontReq {
    /**
     * 符合条件
     */
    private String positive;
    /**
     * 不符合条件
     */
    private String negative;

    public String getNegative() {
        return negative;
    }

    public void setNegative(String negative) {
        this.negative = negative;
    }

    public String getPositive() {
        return positive;
    }

    public void setPositive(String positive) {
        this.positive = positive;
    }
}
