package com.xinwei.comfyui.log.model;

import lombok.Data;

import java.util.Date;

/**
 * @Description: 日志基础对象
 * @Author: xinwei
 * @Date: 2025/3/6 14:22
 * @since 1.8
 */
@Data
public class LogAbstract {
    protected String remoteIp;
    protected String requestUri;
    protected String method;
    protected String methodClass;
    protected String methodName;
    protected Date createTime;

}
