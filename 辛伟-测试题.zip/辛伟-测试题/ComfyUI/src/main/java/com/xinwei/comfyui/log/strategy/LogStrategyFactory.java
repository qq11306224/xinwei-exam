package com.xinwei.comfyui.log.strategy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: 日志策略工厂
 * @Author: xinwei
 * @Date: 2025/3/6 14:22
 * @since 1.8
 */
@Component
public class LogStrategyFactory {

    private final Map<String, LogStrategy> strategyMap = new HashMap<>();
    @Autowired
    public LogStrategyFactory(List<LogStrategy> strategyList) {
        for (LogStrategy strategy : strategyList) {
            strategyMap.put(strategy.getAlias(), strategy);
        }
    }

    public LogStrategy getStrategy(String alias) {
        return strategyMap.get(alias);
    }
} 