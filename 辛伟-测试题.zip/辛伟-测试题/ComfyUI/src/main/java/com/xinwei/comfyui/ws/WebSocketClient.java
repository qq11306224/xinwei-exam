package com.xinwei.comfyui.ws;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;

import javax.websocket.*;
import java.io.IOException;

@ClientEndpoint
public class WebSocketClient {

    private Session session;

    @OnOpen
    public void onOpen(Session session) {
        this.session = session;
        System.out.println("Connected to server");
        try {
            sendMessage("Hello from Java client!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @OnMessage
    public void onMessage(String message) {
      //
        try {
            if ("ping".equals(message)) {
                sendMessage("pong");
            } else {
                JSONObject jsonObject = JSONUtil.parseObj(message);
                if (jsonObject != null && jsonObject.containsKey("type") && jsonObject.getStr("type").equals("progress")) {
                    // 获取 value 和 max
                    JSONObject data = JSONUtil.parseObj(jsonObject.getStr("data"));
                    int value = data.getInt("value");
                    int max = data.getInt("max");
                    String promptId = data.getStr("prompt_id");

                    // 计算进度百分比
                    int percentage = (int) ((double) value / max * 100);

                    // 构建进度条
                    int barLength = 50;
                    int filledLength = (int) (barLength * value / max);
                    if (value == 1) {
                        System.out.println("****************任务开始****************");
                    }
                    StringBuilder bar = new StringBuilder();
                    bar.append("promptId: ").append(promptId).append(" [");
                    for (int i = 0; i < barLength; i++) {
                        if (i < filledLength) {
                            bar.append("=");
                        } else {
                            bar.append(" ");
                        }
                    }
                    bar.append("] ");
                    bar.append(percentage).append("%");

                    // 动态更新进度条
                    System.out.print("\r" + bar.toString());
                    if (value == max) {
                        System.out.println("\r");
                        System.out.println("****************任务结束****************");
                    }
                }else {
                    System.out.println("Received message: " + message);
                }
             //   sendMessage("Message received: " + message);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @OnClose
    public void onClose(CloseReason reason) {
        System.out.println("Connection closed: " + reason.toString());
    }

    @OnError
    public void onError(Throwable error) {
        error.printStackTrace();
    }

    public void sendMessage(String message) throws IOException {
        if (session != null && session.isOpen()) {
            session.getBasicRemote().sendText(message);
        }
    }
}