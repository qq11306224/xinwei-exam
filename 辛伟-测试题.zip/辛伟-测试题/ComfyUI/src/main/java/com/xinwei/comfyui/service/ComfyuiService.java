package com.xinwei.comfyui.service;

import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.xinwei.comfyui.constants.ParamConstatns;
import com.xinwei.comfyui.handler.CumfyuiHandler;
import com.xinwei.comfyui.api.CumfyuiApi;
import com.xinwei.comfyui.log.publisher.ErrorLogPublisher;
import com.xinwei.comfyui.log.publisher.UsualLogPublisher;
import com.xinwei.comfyui.model.QueueResultData;
import com.xinwei.comfyui.utils.GlobalUUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: comfyUi实现类
 * @Author: xinwei
 * @Date: 2025/3/5 23:00
 * @since 1.8
 */
@Slf4j
@Service
public class ComfyuiService {


    /**
     * 生成图片
     *
     * @param positive 符合条件
     * @param negative 不符合条件
     * @return
     */
    @Retryable(value = Exception.class, maxAttempts = 2, backoff = @Backoff(delay = 3000))
    public  String generate(String positive, String negative) {
        String param = String.format(ParamConstatns.PROMPT, GlobalUUID.GLOBAL_UUID, positive, negative);
        String result = null;
        try {
            result = CumfyuiApi.getPrompt(param);
        } catch (Exception e) {
            ErrorLogPublisher.publishEvent(e,"生成图片任务失败,自动重试!");
            throw e;
        }
        JSONObject jsonObject = JSONUtil.parseObj(result);
        if (jsonObject.containsKey("prompt_id") && CharSequenceUtil.isNotBlank(jsonObject.getStr("prompt_id"))) {
            UsualLogPublisher.publishEvent("生成图片任务成功，任务id:" + jsonObject.getStr("prompt_id"));
            return jsonObject.getStr("prompt_id");
        }
        return "";
    }

    /**
     * 超重试次数后降级处理
     * @param e
     * @param positive
     * @param negative
     * @return
     */
    @Recover
    public  String recover(Exception e, String positive, String negative) {
        log.info("生成图片任务失败已超重试次数，采用降级处理。");
         return "";
    }

    /**
     * 获取当前的任务状态信息
     * @param taskId
     * @return
     */
    public   Map<String, String > getTask(String taskId) {
        Map<String, String > resultMap = new LinkedHashMap<>();
        String result = CumfyuiApi.getQueue("");
        JSONObject root = JSONUtil.parseObj(result);
        boolean flag ;
        // 处理 queue_running 队列
       flag = CumfyuiHandler.processQueue(root, "queue_running", taskId);
       if (flag) {
           resultMap.put("message", "当前任务正在运行");
           UsualLogPublisher.publishEvent(String.format("任务id:%s的状态为%s", taskId, "当前任务正在运行"));
           return resultMap;
       }
        // 处理 queue_pending 队列
       flag =  CumfyuiHandler.processQueue(root, "queue_pending", taskId);
        if (flag) {
            resultMap.put("message", "当前任务正在排队");
            UsualLogPublisher.publishEvent(String.format("任务id:%s的状态为%s", taskId, "当前任务正在排队"));
            return resultMap;
        }
        // 处理 queue_history 队列
        result = CumfyuiApi.getHistory(taskId);
        JSONObject history = JSONUtil.parseObj(result);
        if (!history.isEmpty()){
            resultMap.put("message", "当前任务已完成");
            resultMap.put("data", history.toString().replace("\"",""));
            UsualLogPublisher.publishEvent(String.format("任务id:%s的状态为%s", taskId, "当前任务已完成"));
            return resultMap;
        }
        resultMap.put("message", "当前任务不存在");
        UsualLogPublisher.publishEvent(String.format("任务id:%s不存在", taskId));
        return resultMap;
    }

    /**
     * 取消当前任务
     * @return
     */
    public  String interruptTask() {
        CumfyuiApi.getInterrupt();
        UsualLogPublisher.publishEvent("取消当前任务");
        return "";
    }
    /**
     * 删除当前任务/正在排队中的任务
     * @return
     */
    public  String deleteTask(String taskId) {
        Map<String,Object> map = new HashMap<>();
        if(CharSequenceUtil.isBlank(taskId)){
           map.put("clear", true);
        }else {
            map.put("delete", taskId);
        }
        String param = JSONUtil.toJsonStr(map);
        CumfyuiApi.getQueue(param);
        UsualLogPublisher.publishEvent("删除当前任务/正在排队中的任务");
        return "";
    }
    /**
     * 获取运行中的任务ID，排队中的任务ID列表
     * @return
     */
    public  QueueResultData getQueue() {
        String result = CumfyuiApi.getQueue("");
        JSONObject root = JSONUtil.parseObj(result);
        List<String> queueRunning = CumfyuiHandler.processQueueList(root, "queue_running");
        List<String> queuePending = CumfyuiHandler.processQueueList(root, "queue_pending");
        QueueResultData queueResultData = new QueueResultData();
        queueResultData.setQueueRunning(queueRunning);
        queueResultData.setQueuePending(queuePending);
        UsualLogPublisher.publishEvent("获取运行中的任务ID，排队中的任务ID列表");
        return queueResultData;
    }



}
