package com.xinwei.comfyui.log.strategy;

import cn.hutool.json.JSONUtil;
import com.xinwei.comfyui.log.model.LogError;
import com.xinwei.comfyui.log.model.LogUsual;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @Description:  默认打印日志策略实现
 * @Author: xinwei
 * @Date: 2024/10/17
 * @since 1.8
 */
@Component
@Slf4j
public class DefaultLogStrategy implements LogStrategy {


    @Override
    public void saveUsualLog(LogUsual logUsual) {
        log.info("默认打印：日志信息：{}", JSONUtil.toJsonStr(logUsual));
    }

    @Override
    public void saveErrorLog(LogError logError) {
        log.info("默认打印：错误日志信息：{}",JSONUtil.toJsonStr(logError));
    }

    @Override
    public String getAlias() {
        return "default";
    }
} 