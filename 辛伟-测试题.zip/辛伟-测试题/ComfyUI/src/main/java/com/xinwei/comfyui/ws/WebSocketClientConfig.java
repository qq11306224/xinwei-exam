package com.xinwei.comfyui.ws;

import cn.hutool.core.lang.UUID;
import com.xinwei.comfyui.utils.GlobalUUID;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import javax.websocket.*;
import java.net.URI;

@Configuration
public class WebSocketClientConfig {

    @Bean
    public WebSocketClient webSocketClient() {
        try {
            WebSocketContainer container = ContainerProvider.getWebSocketContainer();
            URI uri = new URI("ws://127.0.0.1:8188/ws?clientId="+ GlobalUUID.GLOBAL_UUID);
            WebSocketClient client = new WebSocketClient();
            container.connectToServer(client, uri);
            return client;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}