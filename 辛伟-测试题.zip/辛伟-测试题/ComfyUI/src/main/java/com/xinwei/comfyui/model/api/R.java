
package com.xinwei.comfyui.model.api;

import cn.hutool.core.util.ObjectUtil;

import java.io.Serializable;
import java.util.Optional;
import lombok.Generated;
import org.springframework.lang.Nullable;


/**
 * @Description: 接口返回码
 * @Author: xinwei
 * @Date: 2023/11/17 19:44
 * @since 1.8
 */
public class R<T> implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 状态码
     */
    private int code;
    /**
     * 是否成功
     */
    private boolean success;
    /**
     * 承载数据
     */
    private T data;
    /**
     * 返回消息
     */
    private String msg;

    private R(IResultCode resultCode) {
        this(resultCode, (T) null, resultCode.getMessage());
    }

    private R(IResultCode resultCode, String msg) {
        this(resultCode, (T) null, msg);
    }

    private R(IResultCode resultCode, T data) {
        this(resultCode, data, resultCode.getMessage());
    }

    private R(IResultCode resultCode, T data, String msg) {
        this(resultCode.getCode(), data, msg);
    }

    private R(int code, T data, String msg) {
        this.code = code;
        this.data = data;
        this.msg = msg;
        this.success = ResultCode.SUCCESS.code == code;
    }

    public static boolean isSuccess(@Nullable R<?> result) {
        return (Boolean)Optional.ofNullable(result).map((x) -> ObjectUtil.equal(ResultCode.SUCCESS.code, x.code)).orElse(Boolean.FALSE);
    }

    public static boolean isNotSuccess(@Nullable R<?> result) {
        return !isSuccess(result);
    }

    public static <T> R<T> data(T data) {
        return data(data, "操作成功");
    }

    public static <T> R<T> data(T data, String msg) {
        return data(200, data, msg);
    }

    public static <T> R<T> data(int code, T data, String msg) {
        return new R<T>(code, data, data == null ? "暂无承载数据" : msg);
    }

    public static <T> R<T> success() {
        return new R<T>(ResultCode.SUCCESS);
    }

    public static <T> R<T> success(String msg) {
        return new R<T>(ResultCode.SUCCESS, msg);
    }

    public static <T> R<T> success(IResultCode resultCode) {
        return new R<T>(resultCode);
    }

    public static <T> R<T> success(IResultCode resultCode, String msg) {
        return new R<T>(resultCode, msg);
    }

    public static <T> R<T> fail(String msg) {
        return new R<T>(ResultCode.FAILURE, msg);
    }

    public static <T> R<T> fail(int code, String msg) {
        return new R<T>(code, (T)null, msg);
    }

    public static <T> R<T> fail(IResultCode resultCode) {
        return new R<T>(resultCode);
    }

    public static <T> R<T> fail(IResultCode resultCode, String msg) {
        return new R<T>(resultCode, msg);
    }

    public static <T> R<T> status(boolean flag) {
        return flag ? success("操作成功") : fail("操作失败");
    }

    public static <T> R<T> status(boolean status, String msg) {
        return status ? success() : fail(msg);
    }

    @Generated
    public int getCode() {
        return this.code;
    }

    @Generated
    public boolean isSuccess() {
        return this.success;
    }

    @Generated
    public T getData() {
        return this.data;
    }

    @Generated
    public String getMsg() {
        return this.msg;
    }

    @Generated
    public void setCode(final int code) {
        this.code = code;
    }

    @Generated
    public void setSuccess(final boolean success) {
        this.success = success;
    }

    @Generated
    public void setData(final T data) {
        this.data = data;
    }

    @Generated
    public void setMsg(final String msg) {
        this.msg = msg;
    }


    @Generated
    public R() {
    }
}
