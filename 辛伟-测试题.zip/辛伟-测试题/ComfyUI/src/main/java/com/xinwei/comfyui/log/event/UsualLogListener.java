package com.xinwei.comfyui.log.event;

import com.xinwei.comfyui.log.model.LogUsual;
import com.xinwei.comfyui.log.service.ILogService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.util.ServerInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Async;

import java.util.Map;
/**
 * @Description: 普通日志事件监听
 * @Author: xinwei
 * @Date: 2025/3/6 14:21
 * @since 1.8
 */
public class UsualLogListener {
    private  ILogService logService;

    @Async
    @Order
    @EventListener({UsualLogEvent.class})
    public void saveUsualLog(UsualLogEvent event) {
        Map<String, Object> source = (Map)event.getSource();
        LogUsual logUsual = (LogUsual)source.get("log");
        this.logService.saveUsualLog(logUsual);
    }

    public UsualLogListener(ILogService logService) {
        this.logService = logService;
    }
}
