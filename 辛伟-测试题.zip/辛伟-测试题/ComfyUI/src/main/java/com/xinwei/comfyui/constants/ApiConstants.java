package com.xinwei.comfyui.constants;

/**
 * @Description: 接口常量类
 * @Author: xinwei
 * @Date: 2025/3/5 21:14
 * @since 1.8
 */
public interface ApiConstants {
    String BASE_URL = "http://127.0.0.1:8188/";

    /**
     * 获取所有模型信息
     */
    String OBJECT_INFO = BASE_URL + "object_info";
    /**
     * 获取所有历史任务数据
     */
    String HISTORY  = BASE_URL + "history";
    /**
     * 图片的在线预览接口（上传图像，生图图像，蒙蔽图像，均通过该接口预览）
     */
    String VIEW  = BASE_URL + "view";

    /**
     * get:获取服务器当前剩余任务列队的数量
     * post:绘图任务的下发接口，此接口只做任务下发，返回任务ID信息。 此接口只做任务下发，返回任务ID信息。
     */
    String PROMPT = BASE_URL + "prompt";
    /**
     *  get:获取详细任务队列信息，正在运行的以及排队的任务信息
     *  post: 删除列队/无返回值代表成功（待验证）
     *  {
     *   "delete": "string"
     * }
     * post: 清空排队队列/无返回值代表成功（待验证）
     * {
     *     "clear": true
     * }
     */
    String QUEUE = BASE_URL + "queue";

    /**
     *取消当前任务/不需任何参数
     */
    String INTERRUPT = BASE_URL + "interrupt";
}
