package com.xinwei.comfyui.log.model;

import lombok.Data;
import lombok.ToString;

/**
 * @Description: 通用日志对象
 * @Author: xinwei
 * @Date: 2025/3/6 14:22
 * @since 1.8
 */
@Data
@ToString
public class LogUsual extends LogAbstract {
    private String logData;
}
