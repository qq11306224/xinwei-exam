//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.xinwei.comfyui.log.publisher;

import cn.hutool.extra.spring.SpringUtil;
import com.xinwei.comfyui.log.event.UsualLogEvent;
import com.xinwei.comfyui.log.model.LogUsual;
import com.xinwei.comfyui.log.utils.LogAbstractUtil;
import com.xinwei.comfyui.log.utils.WebUtil;
import jakarta.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description: 普通日志事件发布器
 * @Author: xinwei
 * @Date: 2025/3/6 14:22
 * @since 1.8
 */
public class UsualLogPublisher {
    public UsualLogPublisher() {
    }

    public static void publishEvent(String data) {
        HttpServletRequest request = WebUtil.getRequest();
        LogUsual logUsual = new LogUsual();
        logUsual.setLogData(data);
        LogAbstractUtil.addRequestInfoToLog(request, logUsual);
        Map<String, Object> event = new HashMap(16);
        event.put("log", logUsual);
        event.put("request", request);
        SpringUtil.publishEvent(new UsualLogEvent(event));
    }
}
