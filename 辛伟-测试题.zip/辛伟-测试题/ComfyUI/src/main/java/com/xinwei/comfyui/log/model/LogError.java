package com.xinwei.comfyui.log.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @Description: 异常日志对象
 * @Author: xinwei
 * @Date: 2025/3/6 14:21
 * @since 1.8
 */
@ToString
@Data
public class LogError extends LogAbstract{
    private String stackTrace;
    private String exceptionName;
    private String message;
    private String fileName;
    private Integer lineNumber;
}
