package com.xinwei.comfyui.model;

import lombok.Data;

import java.util.List;

/**
 * 查询当前任务中的状态列表对象
 */
public class QueueResultData {
    private List<String> queueRunning;

    private List<String > queuePending;

    public List<String> getQueueRunning() {
        return queueRunning;
    }

    public void setQueueRunning(List<String> queueRunning) {
        this.queueRunning = queueRunning;
    }

    public List<String> getQueuePending() {
        return queuePending;
    }

    public void setQueuePending(List<String> queuePending) {
        this.queuePending = queuePending;
    }
}

