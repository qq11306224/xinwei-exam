package com.xinwei.comfyui.log.event;

import com.xinwei.comfyui.log.model.LogError;
import com.xinwei.comfyui.log.service.ILogService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.util.ServerInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Async;

import java.util.Map;

/**
 * @Description: 异常日志事件监听
 * @Author: xinwei
 * @Date: 2025/3/6 14:22
 * @since 1.8
 */
@Slf4j
public class ErrorLogListener {

    private  ILogService logService;

    @Async
    @Order
    @EventListener({ErrorLogEvent.class})
    public void saveErrorLog(ErrorLogEvent event) {
        Map<String, Object> source = (Map) event.getSource();
        LogError logError = (LogError) source.get("log");
        this.logService.saveErrorLog(logError);
    }

    public ErrorLogListener(ILogService logService) {
        this.logService = logService;
    }
}

