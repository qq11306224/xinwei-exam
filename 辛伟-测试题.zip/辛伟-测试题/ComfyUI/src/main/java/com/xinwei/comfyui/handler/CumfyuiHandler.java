package com.xinwei.comfyui.handler;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @Description: Cumfyui处理类
 * @Author: xinwei
 * @Date: 2025/3/6 10:27
 * @since 1.8
 */
public class CumfyuiHandler {
    /**
     *  判断当前的任务是否在运行中、排队中
     * @param root
     * @param queueName
     * @param taskId
     * @return
     */
    public static boolean processQueue(JSONObject root, String queueName, String taskId) {
        List<String> list = processQueueList(root, queueName);
        if (CollUtil.isEmpty(list)) return false;
        return list.contains(taskId);
    }

    /**
     *  获取运行中的任务ID，排队中的任务ID列表
     * @param root
     * @param queueName
     * @return
     */
    public static List<String > processQueueList(JSONObject root, String queueName) {
        JSONArray queue = root.getJSONArray(queueName);
        if (queue.isEmpty()) return new ArrayList<>();
        List<String > result = new ArrayList<>();
        // 遍历队列中的每个条目（每个条目是一个JSONArray）
        for (Object entryObj : queue) {
            JSONArray entryArray = (JSONArray) entryObj;
            // 获取索引1的值（即UUID）
            if (entryArray.size() > 1) {
                Object uuidValue = entryArray.get(1);
                if (uuidValue != null) {
                   result.add(uuidValue.toString());
                }
            }
        }
        return result;
    }
}
