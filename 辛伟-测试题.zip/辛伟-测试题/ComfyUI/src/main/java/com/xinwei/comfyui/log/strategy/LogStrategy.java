package com.xinwei.comfyui.log.strategy;

import com.xinwei.comfyui.log.model.LogError;
import com.xinwei.comfyui.log.model.LogUsual;
/**
 * @Description: 日志策略模式接口类
 * @Author: xinwei
 * @Date: 2025/3/6 14:22
 * @since 1.8
 */
public interface LogStrategy {
    /**
     * 保存通用日志
     *
     * @param logUsual
     * @return
     */
    void saveUsualLog(LogUsual logUsual);

    /**
     * 保存错误日志
     *
     * @param logUsual
     * @return
     */
    void saveErrorLog(LogError logError);

    /**
     * 别名
     * @return
     */
    String getAlias();
} 