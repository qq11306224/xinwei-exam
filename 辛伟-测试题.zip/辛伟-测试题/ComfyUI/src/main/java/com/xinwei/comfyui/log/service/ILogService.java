package com.xinwei.comfyui.log.service;

import com.xinwei.comfyui.log.model.LogError;
import com.xinwei.comfyui.log.model.LogUsual;

/**
 * @Description: 日志接口类
 * @Author: xinwei
 * @Date: 2025/3/6 14:27
 * @since 1.8
 */
public interface ILogService {
    /**
     * 保存通用日志
     *
     * @param logUsual
     * @return
     */
    void saveUsualLog(LogUsual logUsual);

    /**
     * 保存错误日志
     *
     * @param logError
     * @return
     */
    void saveErrorLog(LogError logError);
}
