package com.xinwei.comfyui.constants;

/**
 * @Description: 普通常量类
 * @Author: xinwei
 * @Date: 2025/3/5 23:37
 * @since 1.8
 */
public interface CommonConstants {

}
