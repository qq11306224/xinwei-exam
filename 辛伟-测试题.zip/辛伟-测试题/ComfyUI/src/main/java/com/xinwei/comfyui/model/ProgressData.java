package com.xinwei.comfyui.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description: 进度数据类
 * @Author: xinwei
 * @Date: 2025/3/5 22:26
 * @since 1.8
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProgressData {
    private int value;
    private int max;
    private String promptId;
    private String node;
}
