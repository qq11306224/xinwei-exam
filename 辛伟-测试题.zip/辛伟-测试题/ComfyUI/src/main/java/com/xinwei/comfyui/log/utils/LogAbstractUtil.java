//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.xinwei.comfyui.log.utils;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.URLUtil;
import com.xinwei.comfyui.log.model.LogAbstract;
import jakarta.servlet.http.HttpServletRequest;

import java.util.Date;

/**
 * @Description: 日志抽象工具类
 * @Author: xinwei
 * @Date: 2025/3/6 14:22
 * @since 1.8
 */
public class LogAbstractUtil {
    public LogAbstractUtil() {
    }

    public static void addRequestInfoToLog(HttpServletRequest request, LogAbstract logAbstract) {
        if (ObjectUtil.isNotEmpty(request)) {
            logAbstract.setRemoteIp(WebUtil.getIP(request));
            logAbstract.setRequestUri(URLUtil.getPath(request.getRequestURI()));
            logAbstract.setMethod(request.getMethod());
        }
        logAbstract.setCreateTime(new Date());

    }
}
