
package com.xinwei.comfyui.model.api;

import java.io.Serializable;
/**
 * @Description: 接口返回码
 * @Author: xinwei
 * @Date: 2023/11/17 19:44
 * @since 1.8
 */
public interface IResultCode extends Serializable {
    String getMessage();

    int getCode();
}
