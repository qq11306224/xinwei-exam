package com.xinwei.comfyui.log.event;

import org.springframework.context.ApplicationEvent;

import java.util.Map;
/**
 * @Description: 普通日志事件
 * @Author: xinwei
 * @Date: 2025/3/6 14:21
 * @since 1.8
 */
public class UsualLogEvent extends ApplicationEvent {
    public UsualLogEvent(Map<String, Object> source) {
        super(source);
    }
}
