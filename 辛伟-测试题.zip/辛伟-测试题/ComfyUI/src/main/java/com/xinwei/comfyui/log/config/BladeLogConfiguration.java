
package com.xinwei.comfyui.log.config;

import com.xinwei.comfyui.log.event.ErrorLogListener;
import com.xinwei.comfyui.log.event.UsualLogListener;
import com.xinwei.comfyui.log.service.ILogService;
import jakarta.annotation.Resource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 *  日志工具自动配置
 *  @author: xinwei
 *  @date: 2023/4/17 17:18
 *
 */
@Configuration(proxyBeanMethods = false)
public class BladeLogConfiguration {
	@Resource
	private  ILogService logService;


	@Bean(name = "errorEventListener")
	public ErrorLogListener errorEventListener() {
		return new ErrorLogListener(logService);
	}

	@Bean(name = "usualEventListener")
	public UsualLogListener usualEventListener() {
		return new UsualLogListener(logService);
	}
}
