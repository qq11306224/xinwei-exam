package com.xinwei.comfyui.api;

import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.http.HttpUtil;
import com.xinwei.comfyui.constants.ApiConstants;

/**
 * @Description: 调用 CumfyuiApi接口
 * @Author: xinwei
 * @Date: 2025/3/6 10:04
 * @since 1.8
 */
public class CumfyuiApi {
    /**
     * 获取当前的任务队列信息
     *
     * @return
     */
    public static String getObjectInfo() {
        return HttpUtil.get(ApiConstants.OBJECT_INFO);
    }

    /**
     * 获取所有历史任务数据
     *
     * @return
     */
    public static String getHistory(String promptId) {
        if (CharSequenceUtil.isNotBlank(promptId)) {
            return HttpUtil.get(ApiConstants.HISTORY + "/" + promptId);
        }
        return HttpUtil.get(ApiConstants.HISTORY);
    }

    /**
     * 图片的在线预览接口（上传图像，生图图像，蒙蔽图像，均通过该接口预览）
     *
     * @return
     */
    public static String getView() {
        return HttpUtil.get(ApiConstants.VIEW);
    }

    /**
     * 绘图任务的下发接口，此接口只做任务下发，返回任务ID信息。
     *
     * @param param
     * @return
     */
    public static String getPrompt(String param) {
        return HttpUtil.post(ApiConstants.PROMPT, param);
    }

    /**
     *  get:获取详细任务队列信息，正在运行的以及排队的任务信息
     *  post: 删除列队/无返回值代表成功（待验证）
     *  {
     *   "delete": "string"
     * }
     * post: 清空排队队列/无返回值代表成功（待验证）
     * {
     *     "clear": true
     * }
     */
    public static String getQueue(String param) {
        if (CharSequenceUtil.isNotBlank(param)) {
            return HttpUtil.post(ApiConstants.QUEUE, param);
        }
        return HttpUtil.get(ApiConstants.QUEUE);
    }

    /**
     * 取消当前任务/不需任何参数
     *
     * @return
     */
    public static String getInterrupt() {
        return HttpUtil.post(ApiConstants.INTERRUPT,"");
    }

}
