package com.xinwei.comfyui.utils;

/**
 * @Description: 全局唯一ID生成器
 * @Author: xinwei
 * @Date: 2023/11/17 20:01
 * @since 1.8
 */
public class GlobalUUID {
    // 定义一个静态的、不可变的 UUID 变量
    public static final String GLOBAL_UUID = generateUUID();

    // 生成 UUID 的静态方法
    private static String generateUUID() {
       // return IdUtil.simpleUUID();
        return "cccf621f31c14fdbaf40ee4e466294cb";
    }

    public static void main(String[] args) {
        // 测试获取全局 UUID
        System.out.println("全局 UUID: " + GlobalUUID.GLOBAL_UUID);
    }
}