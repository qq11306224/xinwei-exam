package com.xinwei.comfyui.constants;

/**
 * @Description:
 * @Author: xinwei
 * @Date: 2025/3/5 23:22
 * @since 1.8
 */
public interface ParamConstatns {
    /**
     * 绘图任务的下发接口，参数信息。
     */
    String  PROMPT ="{\n" +
            "  \"client_id\": \"%s\",\n" +
            "  \"prompt\": {\n" +
            "  \"3\": {\n" +
            "    \"inputs\": {\n" +
            "      \"seed\": 299001824846137,\n" +
            "      \"steps\": 20,\n" +
            "      \"cfg\": 8,\n" +
            "      \"sampler_name\": \"euler\",\n" +
            "      \"scheduler\": \"normal\",\n" +
            "      \"denoise\": 1,\n" +
            "      \"model\": [\n" +
            "        \"4\",\n" +
            "        0\n" +
            "      ],\n" +
            "      \"positive\": [\n" +
            "        \"6\",\n" +
            "        0\n" +
            "      ],\n" +
            "      \"negative\": [\n" +
            "        \"7\",\n" +
            "        0\n" +
            "      ],\n" +
            "      \"latent_image\": [\n" +
            "        \"5\",\n" +
            "        0\n" +
            "      ]\n" +
            "    },\n" +
            "    \"class_type\": \"KSampler\",\n" +
            "    \"_meta\": {\n" +
            "      \"title\": \"K采样器\"\n" +
            "    }\n" +
            "  },\n" +
            "  \"4\": {\n" +
            "    \"inputs\": {\n" +
            "      \"ckpt_name\": \"v1-5-pruned-emaonly-fp16.safetensors\"\n" +
            "    },\n" +
            "    \"class_type\": \"CheckpointLoaderSimple\",\n" +
            "    \"_meta\": {\n" +
            "      \"title\": \"Checkpoint加载器（简易）\"\n" +
            "    }\n" +
            "  },\n" +
            "  \"5\": {\n" +
            "    \"inputs\": {\n" +
            "      \"width\": 512,\n" +
            "      \"height\": 512,\n" +
            "      \"batch_size\": 1\n" +
            "    },\n" +
            "    \"class_type\": \"EmptyLatentImage\",\n" +
            "    \"_meta\": {\n" +
            "      \"title\": \"空Latent图像\"\n" +
            "    }\n" +
            "  },\n" +
            "  \"6\": {\n" +
            "    \"inputs\": {\n" +
            "      \"text\": \"%s\",\n" +
            "      \"clip\": [\n" +
            "        \"4\",\n" +
            "        1\n" +
            "      ]\n" +
            "    },\n" +
            "    \"class_type\": \"CLIPTextEncode\",\n" +
            "    \"_meta\": {\n" +
            "      \"title\": \"CLIP文本编码\"\n" +
            "    }\n" +
            "  },\n" +
            "  \"7\": {\n" +
            "    \"inputs\": {\n" +
            "      \"text\": \"%s\",\n" +
            "      \"clip\": [\n" +
            "        \"4\",\n" +
            "        1\n" +
            "      ]\n" +
            "    },\n" +
            "    \"class_type\": \"CLIPTextEncode\",\n" +
            "    \"_meta\": {\n" +
            "      \"title\": \"CLIP文本编码\"\n" +
            "    }\n" +
            "  },\n" +
            "  \"8\": {\n" +
            "    \"inputs\": {\n" +
            "      \"samples\": [\n" +
            "        \"3\",\n" +
            "        0\n" +
            "      ],\n" +
            "      \"vae\": [\n" +
            "        \"4\",\n" +
            "        2\n" +
            "      ]\n" +
            "    },\n" +
            "    \"class_type\": \"VAEDecode\",\n" +
            "    \"_meta\": {\n" +
            "      \"title\": \"VAE解码\"\n" +
            "    }\n" +
            "  },\n" +
            "  \"9\": {\n" +
            "    \"inputs\": {\n" +
            "      \"filename_prefix\": "+System.currentTimeMillis()+",\n" +
            "      \"images\": [\n" +
            "        \"8\",\n" +
            "        0\n" +
            "      ]\n" +
            "    },\n" +
            "    \"class_type\": \"SaveImage\",\n" +
            "    \"_meta\": {\n" +
            "      \"title\": \"保存图像\"\n" +
            "    }\n" +
            "  }\n" +
            "}\n" +
            "}";
}
