package com.xinwei.comfyui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComfyUiApplicationTests {

    @Test
    void contextLoads() {
    }

}
