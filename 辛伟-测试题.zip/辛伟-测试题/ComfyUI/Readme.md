ComfyUI 是一个基于 Spring Boot 构建的 Java 项目，主要用于处理图片生成任务。它集成了 WebSocket 通信、日志管理、重试机制和异常处理等功能。以下是该项目的主要结构、技术栈和核心功能的详细说明。

### 1. **技术栈**
- **Spring Boot**：用于快速搭建 Java 项目，提供自动配置和依赖管理。
- **Spring WebSocket**：实现实时的数据传输。
- **Spring Retry**：提供方法重试机制。
- **Spring AOP**：实现横切关注点（如日志、重试等）。
- **Lombok**：简化 Java 代码，减少样板代码。
- **Hutool**：提供各种工具类，简化开发过程。
- **Maven**：用于管理项目依赖和构建。
- **Java 17**：项目所使用的 Java 版本。

### 2. **数据库与缓存**
项目实现了日志存储策略，使用 Redis 和数据库存储日志，提供默认的打印模式。

**项目结构：**
```
com.xinwei.comfyui
├── constants       # 常量类
├── controller      # 前端控制器
├── handler         # Cumfyui处理类
├── api             # Cumfyui接口类
├── log
│   ├── config      # 日志配置类
│   ├── event       # 日志事件相关类
│   ├── model       # 日志模型类
│   ├── publisher   # 日志事件发布器
│   ├── strategy    # 日志存储策略类
│   └── utils       # 日志工具类
├── model           # 通用模型类
├── service         # 服务层类
├── utils           # 工具类
├── ws              # WebSocket 配置类
└── ComfyUiApplication.java  # 项目启动类
```

### 3. **核心功能**

#### **图片生成方法 (ComfyuiService-generate)**
该方法的主要作用是根据 `positive` 和 `negative` 参数生成图片。调用 `CumfyuiApi.getPrompt` 方法来获取生成结果，并返回 `prompt_id`。

```java
@Retryable(value = Exception.class, maxAttempts = 10, backoff = @Backoff(delay = 30000))
public String generate(String positive, String negative) {
    String param = String.format(ParamConstatns.PROMPT, GlobalUUID.GLOBAL_UUID, positive, negative);
    String result = CumfyuiApi.getPrompt(param);
    JSONObject jsonObject = JSONUtil.parseObj(result);
    if (jsonObject.containsKey("prompt_id") && CharSequenceUtil.isNotBlank(jsonObject.getStr("prompt_id"))) {
        UsualLogPublisher.publishEvent("生成图片任务成功，任务id:" + jsonObject.getStr("prompt_id"));
        return jsonObject.getStr("prompt_id");
    }
    throw new RuntimeException("Failed to get prompt_id");
}
@Recover
public static String recover(Exception e, String positive, String negative) {
  log.info("生成图片任务失败已超重试次数，采用降级处理。");
  return "";
}
```

- **重试机制**：使用 `@Retryable` 注解来对异常进行重试。最多重试 10 次，每次重试间隔 30 秒。

- **降级处理：**使用 `@Recover` 注解来对已达到重试最大次数后进行降级处理。

#### **日志发布器 (UsualLogPublisher)**
`UsualLogPublisher` 负责发布日志事件，包括请求信息和日志数据。

```java
public static void publishEvent(String data) {
    HttpServletRequest request = WebUtil.getRequest();
    LogUsual logUsual = new LogUsual();
    logUsual.setLogData(data);
    LogAbstractUtil.addRequestInfoToLog(request, logUsual);
    Map<String, Object> event = new HashMap<>(16);
    event.put("log", logUsual);
    event.put("request", request);
    SpringUtil.publishEvent(new UsualLogEvent(event));
}
```

- 日志数据通过 `LogUsual` 类进行封装，结合请求信息生成日志事件。
- 使用 `SpringUtil.publishEvent()` 方法发布日志事件。

### 4. **使用环境**

#### **开发环境**
- **JDK**：Java 17 或更高版本
- **IDE**：IntelliJ IDEA 或 Eclipse
- **构建工具**：Maven 3.x

#### **运行环境**
- **操作系统**：Windows、Linux 或 macOS
- **JRE**：Java 17 或更高版本
- **Redis 服务器**：用于日志存储（可选）
- **数据库服务器**：用于日志存储（具体数据库类型未明确）

### 5.接口详情

---

#### 1. 生成图片接口
- **接口路径**: `/api/v1/generate`
- **请求方法**: `POST`
- **请求体**: `PomiontReq` 对象，包含以下字段：
  - `positive`: 生成图片的正向提示词
  - `negative`: 生成图片的负向提示词
- **业务逻辑**:
  - 调用 `ComfyuiService` 的 `generate` 方法，传入 `positive` 和 `negative` 参数生成图片任务。
  - 如果生成成功，返回包含 `prompt_id` 的成功响应；否则返回失败响应。
- **响应示例**:
  - 成功：
    ```json
    {
        "code": 200,
        "msg": "生成图片任务创建成功，prompt_id：xxxxxx",
        "data": null
    }
    ```
  - 失败：
    ```json
    {
        "code": 500,
        "msg": "生成失败",
        "data": null
    }
    ```

---

#### 2. 获取任务状态信息接口
- **接口路径**: `/api/v1/tasks/{taskId}`
- **请求方法**: `GET`
- **请求参数**:
  - `taskId`: 任务的 ID，通过路径变量传递。
- **业务逻辑**:
  - 调用 `ComfyuiService` 的 `getTask` 方法，根据 `taskId` 获取任务的状态信息。
  - 将结果封装在 `Map<String, String>` 中返回。
- **响应示例**:
  ```json
  {
      "code": 200,
      "success": true,
      "data": {
          "message": "当前任务正在排队"
      },
      "msg": "操作成功"
  }
  ```

---

#### 3. 获取任务队列信息接口
- **接口路径**: `/api/v1/queue`
- **请求方法**: `GET`
- **业务逻辑**:
  - 调用 `ComfyuiService` 的 `getQueue` 方法，获取运行中的任务 ID 和排队中的任务 ID 列表。
  - 将结果封装在 `QueueResultData` 对象中返回。
- **响应示例**:
  ```json
  {
      "code": 200,
      "success": true,
      "data": {
          "queueRunning": [
              "dde2a8a4-4536-4b2b-bd91-e4addaed7287"
          ],
          "queuePending": [
              "2af0c6d3-12c7-4eae-be0a-520f742a658b",
              "42087d16-715e-44cd-bad1-82cdd8c9a6af",
              "49b1cf03-c4cf-4514-a2ac-459384e5748a"
          ]
      },
      "msg": "操作成功"
  }
  ```

---

#### 4. 取消排队任务接口
- **接口路径**: `/api/v1/tasks`
- **请求方法**: `DELETE`
- **业务逻辑**:
  - 调用 `ComfyuiService` 的 `deleteTask` 方法，取消正在排队中的任务。
  - 返回操作成功的响应。
- **响应示例**:
  ```json
  {
      "code": 200,
      "success": true,
      "data": null,
      "msg": "操作成功"
  }
  ```

---

#### 5. 取消当前执行任务接口
- **接口路径**: `/api/v1/interrupt`
- **请求方法**: `DELETE`
- **业务逻辑**:
  - 调用 `ComfyuiService` 的 `interruptTask` 方法，取消当前正在执行的任务。
  - 返回操作成功的响应。
- **响应示例**:
  ```json
  {
      "code": 200,
      "msg": "取消成功",
      "data": null
  }
  ```

---

### 通用响应对象 `R`
所有接口的响应对象 `R` 是一个通用的响应封装类，包含以下字段：
- `code`: 状态码（如 200 表示成功，500 表示失败）。
- `msg`: 操作结果的描述信息。
- `data`: 返回的数据，可能为 `null` 或具体的数据对象。
- `success`: 操作是否成功（布尔值）。

---

### 总结

ComfyUI 是一个功能丰富的 Java 项目，结合了 Spring Boot 的优势，提供了可靠的重试机制、实时通信和日志管理，适用于需要生成图片并进行任务日志记录的应用场景。它在服务层的实现中使用了 Spring AOP 进行日志管理和重试机制，同时通过 WebSocket 和 Redis 提供了强大的实时数据传输和缓存支持。

